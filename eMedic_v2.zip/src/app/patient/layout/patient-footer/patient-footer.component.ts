import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-footer',
  templateUrl: './patient-footer.component.html',
  styleUrls: ['./patient-footer.component.css']
})
export class PatientFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

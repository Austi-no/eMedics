import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-landing',
  templateUrl: './patient-landing.component.html',
  styleUrls: ['./patient-landing.component.css']
})
export class PatientLandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
